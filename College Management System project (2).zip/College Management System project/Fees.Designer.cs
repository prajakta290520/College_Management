﻿namespace College_Management_System_project
{
    partial class Fees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Fees));
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtRegNumber = new TextBox();
            txtFees = new TextBox();
            fnameLabel = new Label();
            MnameLabel = new Label();
            durationLabel = new Label();
            btnSubmit = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(80, 11);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(262, 128);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(38, 159);
            label1.Name = "label1";
            label1.Size = new Size(234, 29);
            label1.TabIndex = 1;
            label1.Text = "Registeration Number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(38, 205);
            label2.Name = "label2";
            label2.Size = new Size(114, 29);
            label2.TabIndex = 2;
            label2.Text = "Full Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(38, 247);
            label3.Name = "label3";
            label3.Size = new Size(154, 29);
            label3.TabIndex = 3;
            label3.Text = "Mother Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(38, 293);
            label4.Name = "label4";
            label4.Size = new Size(101, 29);
            label4.TabIndex = 4;
            label4.Text = "Duration";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(38, 334);
            label5.Name = "label5";
            label5.Size = new Size(58, 29);
            label5.TabIndex = 5;
            label5.Text = "Fees";
            label5.Click += label5_Click;
            // 
            // txtRegNumber
            // 
            txtRegNumber.Font = new Font("Calibri", 9F, FontStyle.Bold, GraphicsUnit.Point);
            txtRegNumber.Location = new Point(277, 159);
            txtRegNumber.Margin = new Padding(2);
            txtRegNumber.Name = "txtRegNumber";
            txtRegNumber.Size = new Size(138, 29);
            txtRegNumber.TabIndex = 6;
            txtRegNumber.TextChanged += txtRegNumber_TextChanged;
            // 
            // txtFees
            // 
            txtFees.Font = new Font("Calibri", 9F, FontStyle.Bold, GraphicsUnit.Point);
            txtFees.Location = new Point(277, 343);
            txtFees.Margin = new Padding(2);
            txtFees.Name = "txtFees";
            txtFees.Size = new Size(138, 29);
            txtFees.TabIndex = 7;
            // 
            // fnameLabel
            // 
            fnameLabel.AutoSize = true;
            fnameLabel.Font = new Font("Calibri", 9F, FontStyle.Bold, GraphicsUnit.Point);
            fnameLabel.Location = new Point(277, 211);
            fnameLabel.Margin = new Padding(2, 0, 2, 0);
            fnameLabel.Name = "fnameLabel";
            fnameLabel.Size = new Size(55, 22);
            fnameLabel.TabIndex = 8;
            fnameLabel.Text = "_____";
            // 
            // MnameLabel
            // 
            MnameLabel.AutoSize = true;
            MnameLabel.Font = new Font("Calibri", 9F, FontStyle.Bold, GraphicsUnit.Point);
            MnameLabel.Location = new Point(277, 247);
            MnameLabel.Margin = new Padding(2, 0, 2, 0);
            MnameLabel.Name = "MnameLabel";
            MnameLabel.Size = new Size(55, 22);
            MnameLabel.TabIndex = 9;
            MnameLabel.Text = "_____";
            // 
            // durationLabel
            // 
            durationLabel.AutoSize = true;
            durationLabel.Font = new Font("Calibri", 9F, FontStyle.Bold, GraphicsUnit.Point);
            durationLabel.Location = new Point(277, 293);
            durationLabel.Margin = new Padding(2, 0, 2, 0);
            durationLabel.Name = "durationLabel";
            durationLabel.Size = new Size(55, 22);
            durationLabel.TabIndex = 10;
            durationLabel.Text = "_____";
            durationLabel.Click += label8_Click;
            // 
            // btnSubmit
            // 
            btnSubmit.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnSubmit.Location = new Point(188, 371);
            btnSubmit.Margin = new Padding(2);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(112, 38);
            btnSubmit.TabIndex = 11;
            btnSubmit.Text = "Submit";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // Fees
            // 
            AutoScaleDimensions = new SizeF(9F, 22F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(438, 420);
            Controls.Add(btnSubmit);
            Controls.Add(durationLabel);
            Controls.Add(MnameLabel);
            Controls.Add(fnameLabel);
            Controls.Add(txtFees);
            Controls.Add(txtRegNumber);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Font = new Font("Calibri", 9F, FontStyle.Bold, GraphicsUnit.Point);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Fees";
            Text = "Submit";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtRegNumber;
        private TextBox txtFees;
        private Label fnameLabel;
        private Label MnameLabel;
        private Label durationLabel;
        private Button btnSubmit;
    }
}