﻿namespace College_Management_System_project
{
    partial class UpgradeSemester
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpgradeSemester));
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            comboBoxFrom = new ComboBox();
            comboBoxTo = new ComboBox();
            btnUpgrade = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(37, 29);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(468, 152);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Elephant", 9.999999F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(-8, 195);
            label1.Name = "label1";
            label1.Size = new Size(482, 26);
            label1.TabIndex = 1;
            label1.Text = "Select Semester for Old Student Admission";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft JhengHei UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(59, 239);
            label2.Name = "label2";
            label2.Size = new Size(66, 23);
            label2.TabIndex = 2;
            label2.Text = "From :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft JhengHei UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(70, 289);
            label3.Name = "label3";
            label3.Size = new Size(43, 23);
            label3.TabIndex = 3;
            label3.Text = "To :";
            // 
            // comboBoxFrom
            // 
            comboBoxFrom.FormattingEnabled = true;
            comboBoxFrom.Items.AddRange(new object[] { "1st sem", "2nd sem", "3rd sem", "4th sem", "5th sem", "6th sem", "7th sem", "8th sem" });
            comboBoxFrom.Location = new Point(168, 232);
            comboBoxFrom.Name = "comboBoxFrom";
            comboBoxFrom.Size = new Size(242, 31);
            comboBoxFrom.TabIndex = 4;
            comboBoxFrom.Text = "---Select---";
            // 
            // comboBoxTo
            // 
            comboBoxTo.FormattingEnabled = true;
            comboBoxTo.Items.AddRange(new object[] { "1st sem", "2nd sem", "3rd sem", "4th sem", "5th sem", "6th sem", "7th sem", "8th sem" });
            comboBoxTo.Location = new Point(168, 282);
            comboBoxTo.Name = "comboBoxTo";
            comboBoxTo.Size = new Size(242, 31);
            comboBoxTo.TabIndex = 5;
            comboBoxTo.Text = "---Select---";
            // 
            // btnUpgrade
            // 
            btnUpgrade.Location = new Point(212, 356);
            btnUpgrade.Name = "btnUpgrade";
            btnUpgrade.Size = new Size(112, 34);
            btnUpgrade.TabIndex = 6;
            btnUpgrade.Text = "Upgrade";
            btnUpgrade.UseVisualStyleBackColor = true;
            btnUpgrade.Click += btnUpgrade_Click;
            // 
            // UpgradeSemester
            // 
            AutoScaleDimensions = new SizeF(11F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(536, 440);
            Controls.Add(btnUpgrade);
            Controls.Add(comboBoxTo);
            Controls.Add(comboBoxFrom);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Font = new Font("Microsoft JhengHei UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            Name = "UpgradeSemester";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "UpgradeSemester";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox comboBoxFrom;
        private ComboBox comboBoxTo;
        private Button btnUpgrade;
    }
}