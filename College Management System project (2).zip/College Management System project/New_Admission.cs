﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;


namespace College_Management_System_project
{
    public partial class New_Admission : Form
    {
        public New_Admission()
        {
            InitializeComponent();
        }

        private void New_Admission_Load(object sender, EventArgs e)
        {

        }
        string gender;
        string semester;
        string program;
        string duration;


        private void btnSubmit_Click(object sender, EventArgs e)
        {
            int id = 1;

            string cs = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            string query = "Insert into NewAdmission values(@fname,@mname,@gender,@email,@semester,@prog,@sname,@duration,@addres)";


            // conn.ConnectionString = "data source= DESKTOP-T2I1619\\SQLEXPRESS; database =college;integrated security=True";
            SqlCommand cmd = new SqlCommand(query, conn);
            // cmd.Connection = conn;
            // string query = "Insert into NewAdmission values(@fname,@mname,@gender,@dob,@mobile,@email,@semester,@prog,@sname,@duration,@addres)";

           // cmd.Parameters.AddWithValue("@d", id);
            cmd.Parameters.AddWithValue("@fname", txtFullName.Text);
            cmd.Parameters.AddWithValue("@mname", txtMotherName.Text);
            cmd.Parameters.AddWithValue("@gender", gender);

            
            Int64 mobile = Int64.Parse(txtMobile.Text);
            cmd.Parameters.AddWithValue("@email", txtEmail.Text);
            cmd.Parameters.AddWithValue("@semester", txtSemester.SelectedItem);
            cmd.Parameters.AddWithValue("@prog", txtProgramming.SelectedItem);
            cmd.Parameters.AddWithValue("@sname", txtSchool.Text);
            cmd.Parameters.AddWithValue("@duration", txtDuration.SelectedItem);
            cmd.Parameters.AddWithValue("@addres", txtAddress.Text);
            cmd.ExecuteNonQuery();
            conn.Close();




        }



        /* String name = txtFullName.Text;
         String mname = txtMotherName.Text;
         String gender = "";
         bool isChecked = radioButtonMale.Checked;
         if (isChecked)
         {
             gender = radioButtonMale.Text;

         }
         else
         {
             gender = radioButtonFemale.Text;
         }
         String dob = dateTimePickerDOB.Text;
         Int64 mobile = Int64.Parse(txtMobile.Text);
         String email = txtEmail.Text;
         String semester = txtSemester.Text;
         String Program = txtProgramming.Text;
         String sname = txtSchool.Text;
         String duration = txtDuration.Text;
         String add = txtAddress.Text;
         conn.Open();

         SqlConnection con = new SqlConnection();

         con.ConnectionString = "data source= DESKTOP-T2I1619\\SQLEXPRESS; database =college;integrated security=True";
         SqlCommand cmd = new SqlCommand();
         cmd.Connection = con;

         cmd.CommandText = "insert into NewAdmission (fname,mname,gender,dob,mobile ,email,semester,prog,sname,duration,addres) values ('" + name + " ' ,'" + mname + " ','" + gender + " ','" + dob + " ','" + mobile + " ','" + email + " ','" + semester + " ','" + Program + "',' " + sname + " ','" + duration + " ','" + add + "')";


         SqlDataAdapter DA = new SqlDataAdapter(cmd);
         DataSet DS = new DataSet();
         DA.Fill(DS);
         conn.Close();
         MessageBox.Show("Data Saved.Remember the Registeration ID", "Data", MessageBoxButtons.OK, MessageBoxIcon.Hand); */


        private void txtSemester_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtFullName.Clear();
            txtAddress.Clear();
            txtMotherName.Clear();
            radioButtonFemale.Checked = false;
            radioButtonMale.Checked = false;
            txtMobile.Clear();
            txtEmail.Clear();
            txtProgramming.ResetText();
            txtSemester.ResetText();
            txtSchool.ResetText();
            txtDuration.ResetText();
        }

        private void radioButtonMale_CheckedChanged(object sender, EventArgs e)
        {
            bool isChecked = radioButtonMale.Checked;
            if (isChecked)
            {
                gender = radioButtonMale.Text;

            }
        }

        private void radioButtonFemale_CheckedChanged(object sender, EventArgs e)
        {
            bool isChecked = radioButtonFemale.Checked;
            if (isChecked)
            {
                gender = radioButtonFemale.Text;

            }
        }
    }
}
