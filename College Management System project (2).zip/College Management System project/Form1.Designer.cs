﻿namespace College_Management_System_project
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            btnlogin = new Button();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label5 = new Label();
            label4 = new Label();
            menuStrip1 = new MenuStrip();
            admissionToolStripMenuItem = new ToolStripMenuItem();
            newAdmissionToolStripMenuItem = new ToolStripMenuItem();
            upgradeToolStripMenuItem = new ToolStripMenuItem();
            feesToolStripMenuItem = new ToolStripMenuItem();
            aboutUsToolStripMenuItem = new ToolStripMenuItem();
            exitSystemToolStripMenuItem = new ToolStripMenuItem();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(0, 75);
            label1.Name = "label1";
            label1.Size = new Size(116, 32);
            label1.TabIndex = 0;
            label1.Text = "COLLEGE";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(0, 120);
            label2.Name = "label2";
            label2.Size = new Size(194, 32);
            label2.TabIndex = 1;
            label2.Text = "MANAGEMENT";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(0, 152);
            label3.Name = "label3";
            label3.Size = new Size(110, 32);
            label3.TabIndex = 2;
            label3.Text = "SYSTEM";
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(btnlogin);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Location = new Point(465, 26);
            panel1.Name = "panel1";
            panel1.Size = new Size(279, 222);
            panel1.TabIndex = 3;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(76, 15);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(169, 50);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // btnlogin
            // 
            btnlogin.Location = new Point(118, 166);
            btnlogin.Name = "btnlogin";
            btnlogin.Size = new Size(112, 34);
            btnlogin.TabIndex = 6;
            btnlogin.Text = "Login";
            btnlogin.UseVisualStyleBackColor = true;
            btnlogin.Click += btnlogin_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(126, 129);
            textBox2.Name = "textBox2";
            textBox2.PasswordChar = '*';
            textBox2.Size = new Size(150, 31);
            textBox2.TabIndex = 5;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(118, 87);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(150, 31);
            textBox1.TabIndex = 4;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(7, 135);
            label5.Name = "label5";
            label5.Size = new Size(101, 28);
            label5.TabIndex = 1;
            label5.Text = "Password";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(3, 87);
            label4.Name = "label4";
            label4.Size = new Size(106, 28);
            label4.TabIndex = 0;
            label4.Text = "Username";
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { admissionToolStripMenuItem, feesToolStripMenuItem, aboutUsToolStripMenuItem, exitSystemToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1393, 32);
            menuStrip1.TabIndex = 4;
            menuStrip1.Text = "menuStrip1";
            // 
            // admissionToolStripMenuItem
            // 
            admissionToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { newAdmissionToolStripMenuItem, upgradeToolStripMenuItem });
            admissionToolStripMenuItem.Font = new Font("Stencil", 8F, FontStyle.Regular, GraphicsUnit.Point);
            admissionToolStripMenuItem.Image = (Image)resources.GetObject("admissionToolStripMenuItem.Image");
            admissionToolStripMenuItem.Name = "admissionToolStripMenuItem";
            admissionToolStripMenuItem.Size = new Size(133, 28);
            admissionToolStripMenuItem.Text = "Admission";
            admissionToolStripMenuItem.TextAlign = ContentAlignment.TopCenter;
            // 
            // newAdmissionToolStripMenuItem
            // 
            newAdmissionToolStripMenuItem.Name = "newAdmissionToolStripMenuItem";
            newAdmissionToolStripMenuItem.Size = new Size(270, 34);
            newAdmissionToolStripMenuItem.Text = "New Admission";
            newAdmissionToolStripMenuItem.Click += newAdmissionToolStripMenuItem_Click;
            // 
            // upgradeToolStripMenuItem
            // 
            upgradeToolStripMenuItem.Name = "upgradeToolStripMenuItem";
            upgradeToolStripMenuItem.Size = new Size(270, 34);
            upgradeToolStripMenuItem.Text = " Upgrade Semester";
            upgradeToolStripMenuItem.Click += upgradeToolStripMenuItem_Click;
            // 
            // feesToolStripMenuItem
            // 
            feesToolStripMenuItem.Font = new Font("Stencil", 8F, FontStyle.Regular, GraphicsUnit.Point);
            feesToolStripMenuItem.Image = (Image)resources.GetObject("feesToolStripMenuItem.Image");
            feesToolStripMenuItem.Name = "feesToolStripMenuItem";
            feesToolStripMenuItem.Size = new Size(85, 28);
            feesToolStripMenuItem.Text = "Fees";
            feesToolStripMenuItem.TextAlign = ContentAlignment.TopCenter;
            feesToolStripMenuItem.Click += feesToolStripMenuItem_Click;
            // 
            // aboutUsToolStripMenuItem
            // 
            aboutUsToolStripMenuItem.Font = new Font("Stencil", 8F, FontStyle.Regular, GraphicsUnit.Point);
            aboutUsToolStripMenuItem.Image = (Image)resources.GetObject("aboutUsToolStripMenuItem.Image");
            aboutUsToolStripMenuItem.Name = "aboutUsToolStripMenuItem";
            aboutUsToolStripMenuItem.Size = new Size(125, 28);
            aboutUsToolStripMenuItem.Text = "About Us";
            aboutUsToolStripMenuItem.TextAlign = ContentAlignment.TopCenter;
            aboutUsToolStripMenuItem.Click += aboutUsToolStripMenuItem_Click;
            // 
            // exitSystemToolStripMenuItem
            // 
            exitSystemToolStripMenuItem.Font = new Font("Stencil", 8F, FontStyle.Regular, GraphicsUnit.Point);
            exitSystemToolStripMenuItem.Image = (Image)resources.GetObject("exitSystemToolStripMenuItem.Image");
            exitSystemToolStripMenuItem.Name = "exitSystemToolStripMenuItem";
            exitSystemToolStripMenuItem.Size = new Size(148, 28);
            exitSystemToolStripMenuItem.Text = "Exit System";
            exitSystemToolStripMenuItem.Click += exitSystemToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Zoom;
            ClientSize = new Size(1393, 450);
            Controls.Add(panel1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            Name = "Form1";
            WindowState = FormWindowState.Maximized;
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Panel panel1;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label5;
        private Label label4;
        private Button btnlogin;
        private PictureBox pictureBox1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem admissionToolStripMenuItem;
        private ToolStripMenuItem newAdmissionToolStripMenuItem;
        private ToolStripMenuItem upgradeToolStripMenuItem;
        private ToolStripMenuItem feesToolStripMenuItem;
        private ToolStripMenuItem aboutUsToolStripMenuItem;
        private ToolStripMenuItem exitSystemToolStripMenuItem;
    }
}
